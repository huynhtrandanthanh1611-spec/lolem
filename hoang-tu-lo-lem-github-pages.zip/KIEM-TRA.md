# Kết quả kiểm tra ngày 18/09/2026

## Đã kiểm tra trực tiếp trên website gốc
- Mở trang chủ, chuyển chế độ Chạm, bắt đầu lượt 10 câu.
- Trả lời đúng và sai, tăng điểm, phần thưởng xuất hiện trên hành trình.
- Kết thúc với 6 đúng, 4 sai, điểm 6/10.
- Chơi lại trở về câu 1/10, điểm 0.
- Mở màn Bộ câu hỏi và Thiết lập; quan sát các nút nhập/xuất câu hỏi, thêm/sửa/xóa, nhạc và tham số chơi.
- Các ảnh img ở trang chủ đều tải thành công.

## Đã kiểm tra tĩnh trên bản chuyển
- Cú pháp JavaScript của app.js, rewards.js, tilt-controller.js hợp lệ.
- Các đường dẫn tệp trực tiếp trong HTML/CSS/JS có đích tồn tại.
- Có mô hình face_landmarker.task, vision.mjs, hai bộ JS/WASM SIMD và non-SIMD.
- Hai tệp WASM có header WebAssembly hợp lệ.
- Có font Nunito cục bộ; không cần tải mã, ảnh, font hoặc mô hình từ ChatGPT Sites.
- Không thấy mẫu token/API key/private key thông dụng trong các tệp mã. Đây không phải kiểm toán bảo mật toàn diện.

## Chưa kiểm chứng
- Chưa tạo repository và chưa triển khai GitHub Pages.
- Chưa chạy thử bản chuyển trên hosting mới.
- Chưa kiểm tra camera thật, hiệu chỉnh và nhận diện nghiêng đầu.
- Chưa nghe thử/nhập nhạc, nhập/xuất/sửa câu hỏi hoặc lưu thiết lập.
- Chưa kiểm tra giao diện bằng viewport điện thoại.

Kết quả thử tương tác ở trên thuộc website gốc, không phải bằng chứng bản GitHub Pages đã hoạt động.
