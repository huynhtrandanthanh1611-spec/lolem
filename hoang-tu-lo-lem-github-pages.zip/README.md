# Cỗ Xe Thần Tiên — bản chuyển từ website đang chạy

Tải từ website do người dùng cung cấp ngày 18/09/2026. Đây là mã JavaScript đã xuất bản, không phải bản phục dựng trong ZIP standalone cũ.

## Đưa lên GitHub Pages
Tạo repository công khai mới, tải toàn bộ nội dung thư mục này lên nhánh main. index.html phải nằm ngay ở gốc repository, cạnh app.js và thư mục assets.
Trong Settings → Pages, chọn Deploy from a branch, nhánh main, thư mục / (root), rồi Save. Không cần npm hoặc build.

## Những thay đổi để chuyển hosting
- Đổi đường dẫn tuyệt đối thành tương đối để chạy dưới tên repository.
- Chép hình WebP, MediaPipe, mô hình khuôn mặt, cả hai bộ WASM và font Nunito vào assets.
- Bỏ đoạn kiểm tra Cloudflare được hosting cũ chèn vào HTML; đây không phải logic trò chơi.
- Giữ nguyên logic game, câu hỏi mặc định và danh sách phần thưởng đang có trên website gốc.

## Dữ liệu riêng trên thiết bị
Câu hỏi và thiết lập lưu trong localStorage, nhạc giáo viên chọn lưu trong IndexedDB. Chúng không tự chuyển sang tên miền mới. Trước khi chuyển, xuất câu hỏi từ website cũ, rồi nhập vào website mới; chọn lại tệp nhạc và thiết lập nếu cần. Gói này không chứa dữ liệu riêng trong trình duyệt của giáo viên.

## Cập nhật mà giữ nguyên link
Cập nhật tệp trong chính repository và nhánh main đang xuất bản. Giữ nguyên tên tài khoản, tên repository và cấu hình Pages. Chờ lần triển khai hoàn tất. Đổi câu hỏi ở giao diện game chỉ lưu trên trình duyệt đó; muốn đổi mặc định cho mọi người cần sửa dữ liệu defaults trong app.js.

## Giới hạn kiểm chứng
Xem KIEM-TRA.md. Chưa xuất bản GitHub Pages; chưa có link chơi mới được xác nhận.
